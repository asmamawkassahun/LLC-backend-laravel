<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Order\ApplyPromoCodeRequest;
use App\Http\Requests\Order\CreateOrderRequest;
use App\Http\Requests\Order\GeneratePdfFromFormDataRequest;
use App\Http\Requests\Order\UpdateOrderRequest;
use App\Http\Resources\OrderResource;
use App\Services\CompanyFormationService;
use App\Services\NotificationService;
use App\Services\OrderService;
use App\Services\OrderPdfService;
use App\Models\registeredAgentAddress;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class OrderController extends Controller
{
    public function __construct(
        protected OrderService $orderService,
        protected CompanyFormationService $companyFormationService,
        protected NotificationService $notificationService,
        protected OrderPdfService $orderPdfService
    ) {}

    public function index(Request $request): JsonResponse
    {
        $perPage = $request->input('per_page', 15);
        $perPage = min(max((int) $perPage, 1), 100); // Limit between 1 and 100

        $orders = $request->user()->orders()
            ->with([
                'country',
                'pricingPlan',
                'company',
                'company.owners',
                'company.addresses',
                'state',
                'payments'
            ])
            ->latest()
            ->paginate($perPage);

        return response()->json([
            'data' => OrderResource::collection($orders->items()),
            'current_page' => $orders->currentPage(),
            'last_page' => $orders->lastPage(),
            'per_page' => $orders->perPage(),
            'total' => $orders->total(),
        ]);
    }

    public function store(CreateOrderRequest $request): JsonResponse
    {
        $order = $this->orderService->createOrder($request->validated(), $request->user());

        $this->notificationService->sendOrderNotification($order, 'order_created');

        return response()->json(new OrderResource($order->load(['country', 'pricingPlan', 'company', 'state'])), 201);
    }

    public function show(Request $request, $id): JsonResponse
    {
        $order = $request->user()->orders()
            ->with([
                'country',
                'pricingPlan',
                'company',
                'company.owners',
                'company.addresses.registeredAgentAddress',
                'company.country',
                'company.state',
                'state',
                'payments'
            ])
            ->findOrFail($id);

        return response()->json(new OrderResource($order));
    }

    public function update(UpdateOrderRequest $request, $id): JsonResponse
    {
        $order = $request->user()->orders()->findOrFail($id);
        
        $updatedOrder = $this->orderService->updateOrder($order, $request->validated(), $request->user());

        $this->notificationService->sendOrderNotification($updatedOrder, 'order_updated');

        return response()->json(new OrderResource($updatedOrder->load([
            'country',
            'pricingPlan',
            'company',
            'company.owners',
            'company.addresses.registeredAgentAddress',
            'company.country',
            'company.state',
            'state'
        ])));
    }

    public function getRegisteredAgentAddress(Request $request): JsonResponse
    {
        $countryName = $request->query('country');
        
        $query = registeredAgentAddress::with('country')
            ->where('is_active', true);
        
        // Filter by country if provided
        if ($countryName) {
            $query->whereHas('country', function ($q) use ($countryName) {
                $q->where('name', $countryName);
            });
        }
        
        $address = $query->first();

        if (!$address) {
            $message = $countryName 
                ? "No active registered agent address found for {$countryName}"
                : 'No active registered agent address found';
            return response()->json(['message' => $message], 404);
        }

        return response()->json([
            'data' => [
                'id' => $address->id,
                'address' => $address->address,
                'city' => $address->city,
                'state' => $address->state,
                'postal_code' => $address->postal_code,
                'country' => $address->country->name ?? null,
            ]
        ]);
    }

    public function getPrimaryCompanyOrder(Request $request): JsonResponse
    {
        $user = $request->user();
        
        // Get primary company order (order where company has is_primary = true)
        $primaryOrder = $user->orders()
            ->whereHas('company', function ($query) {
                $query->where('is_primary', true);
            })
            ->whereNotNull('company_id')
            ->with([
                'country',
                'pricingPlan',
                'company',
                'company.owners',
                'company.addresses',
                'company.country',
                'company.state',
                'state',
                'payments'
            ])
            ->latest()
            ->first();

        if (!$primaryOrder) {
            return response()->json([
                'data' => null,
                'message' => 'No primary company order found'
            ], 404);
        }

        return response()->json([
            'data' => new OrderResource($primaryOrder)
        ]);
    }

    public function applyPromoCode(ApplyPromoCodeRequest $request, $id): JsonResponse
    {
        $order = $request->user()->orders()->findOrFail($id);
        $totals = $this->orderService->applyPromoCode($order, $request->code);

        return response()->json([
            'message' => 'Promo code applied successfully',
            'totals' => $totals,
        ]);
    }

    public function cancel(Request $request, $id): JsonResponse
    {
        $order = $request->user()->orders()->findOrFail($id);

        if ($order->status->value !== 'pending') {
            return response()->json(['message' => 'Order cannot be cancelled'], 422);
        }

        $request->validate(['reason' => 'nullable|string|max:500']);

        $this->orderService->updateOrderStatus($order, \App\Enums\OrderStatus::CANCELLED);
        $order->update(['cancellation_reason' => $request->reason]);

        return response()->json(['message' => 'Order cancelled successfully']);
    }

    public function destroy(Request $request, $id): JsonResponse
    {
        $order = $request->user()->orders()->findOrFail($id);
        
        // Prevent deletion of paid orders
        if ($order->payment_status->value === 'paid') {
            return response()->json([
                'message' => 'Cannot delete paid orders. Please cancel the order instead.'
            ], 422);
        }
        
        // Prevent deletion of orders that are confirmed
        if (in_array($order->status->value, ['confirmed'])) {
            return response()->json([
                'message' => 'Cannot delete orders that are confirmed.'
            ], 422);
        }
        
        try {
            // Delete related payments first (if any)
            $order->payments()->delete();
            
            // Delete the order
            $order->delete();
            
            return response()->json([
                'message' => 'Order deleted successfully'
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to delete order: ' . $e->getMessage()
            ], 500);
        }
    }

    public function downloadOrderSummary(Request $request, $id): Response
    {
        $order = $request->user()->orders()->findOrFail($id);
        
        try {
            $pdf = $this->orderPdfService->generateOrderSummaryPdf($order);
            
            $filename = 'order-summary-' . $order->order_number . '.pdf';
            
            return response($pdf, 200, [
                'Content-Type' => 'application/pdf',
                'Content-Disposition' => 'attachment; filename="' . $filename . '"',
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to generate PDF: ' . $e->getMessage()
            ], 500);
        }
    }

    public function generatePdfFromFormData(GeneratePdfFromFormDataRequest $request): Response
    {
        try {
            $userEmail = $request->user()->email;
            $pdf = $this->orderPdfService->generateOrderSummaryPdfFromFormData($request->validated(), $userEmail);
            
            $filename = 'order-summary-preview.pdf';
            
            return response($pdf, 200, [
                'Content-Type' => 'application/pdf',
                'Content-Disposition' => 'attachment; filename="' . $filename . '"',
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Failed to generate PDF: ' . $e->getMessage()
            ], 500);
        }
    }
}
